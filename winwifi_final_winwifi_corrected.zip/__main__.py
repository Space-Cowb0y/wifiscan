from main import WiFiAp

if __name__ == "__main__":
    WiFiAp.scan()
