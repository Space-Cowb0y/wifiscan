import sqlite3
import pandas as pd
from datetime import datetime

def conectar_db():
    return sqlite3.connect("wifi_data.db")

def listar_todas():
    conn = conectar_db()
    df = pd.read_sql_query("SELECT * FROM redes_detectadas ORDER BY data_hora DESC", conn)
    conn.close()
    print(df)

def buscar_por_ssid():
    ssid = input("Digite o SSID: ").strip()
    conn = conectar_db()
    df = pd.read_sql_query("SELECT * FROM redes_detectadas WHERE ssid LIKE ? ORDER BY data_hora DESC", conn, params=(f"%{ssid}%",))
    conn.close()
    print(df)

def buscar_por_data():
    data = input("Digite a data (YYYY-MM-DD): ").strip()
    conn = conectar_db()
    df = pd.read_sql_query("SELECT * FROM redes_detectadas WHERE date(data_hora) = ? ORDER BY data_hora DESC", conn, params=(data,))
    conn.close()
    print(df)

def exportar_para_excel():
    conn = conectar_db()
    df = pd.read_sql_query("SELECT * FROM redes_detectadas ORDER BY data_hora DESC", conn)
    conn.close()
    nome_arquivo = f"historico_exportado_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    df.to_excel(nome_arquivo, index=False)
    print(f"Exportado para {nome_arquivo}")

def menu():
    while True:
        print("\n==== MENU ====")
        print("1. Listar todas as redes salvas")
        print("2. Buscar por SSID")
        print("3. Buscar por data")
        print("4. Exportar histórico para Excel")
        print("5. Sair")
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            listar_todas()
        elif opcao == "2":
            buscar_por_ssid()
        elif opcao == "3":
            buscar_por_data()
        elif opcao == "4":
            exportar_para_excel()
        elif opcao == "5":
            break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    menu()
