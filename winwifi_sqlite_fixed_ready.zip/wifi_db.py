
import sqlite3
import pandas as pd
from datetime import datetime
import os

DB_PATH = "wifi_data.db"

# Inicializa o banco de dados
def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS redes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ssid TEXT,
                bssid TEXT,
                signal INTEGER,
                security TEXT,
                data_hora TEXT
            )
        ''')

# Salva redes no banco
def salvar_redes(redes):
    data_hora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with sqlite3.connect(DB_PATH) as conn:
        for r in redes:
            conn.execute('''
                INSERT INTO redes (ssid, bssid, signal, security, data_hora)
                VALUES (?, ?, ?, ?, ?)
            ''', (r['ssid'], r['bssid'], r['signal'], r['security'], data_hora))

# Exporta para arquivos Excel
def exportar_para_excel():
    with sqlite3.connect(DB_PATH) as conn:
        df = pd.read_sql_query("SELECT * FROM redes", conn)
        todas_path = os.path.join(os.getcwd(), "todas_as_redes.xlsx")
        abertas_path = os.path.join(os.getcwd(), "redes_abertas.xlsx")
        df.to_excel(todas_path, index=False)
        df[df['security'].str.lower() == 'open'].to_excel(abertas_path, index=False)
