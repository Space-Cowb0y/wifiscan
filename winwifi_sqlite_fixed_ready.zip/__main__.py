from main import WiFiAp, WinWiFi

if __name__ == "__main__":
    aps = WiFiAp.scan()
    WinWiFi.salvar_em_sqlite(aps)
